document.getElementsByTagName("h1")[0].style.fontSize = "3vw";
document.getElementsByTagName("h2")[0].style.fontSize = "2vw";
document.getElementsByTagName("h3")[0].style.fontSize = "2vw";
document.getElementsByTagName("h4")[0].style.fontSize = "2vw";
document.getElementsByTagName("h5")[0].style.fontSize = "2vw";
document.getElementsByTagName("h6")[0].style.fontSize = "2vw";
document.getElementsByTagName("h7")[0].style.fontSize = "2vw";
